#!/bin/bash

# 🚀 UTI Board 360 - Setup Automatizado do GitHub (NON-INTERACTIVE)
# Este script automatiza a configuração do Git e GitHub sem prompts interativos

set -e

echo "🩺 UTI Board 360 - Setup do GitHub (Auto Mode)"
echo "=============================================="
echo ""

# Cores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Verificar se estamos no diretório correto
if [ ! -f "README.md" ] || [ ! -f "docker-compose.yml" ]; then
    echo "❌ Este script deve ser executado na raiz do projeto UTI Board 360"
    exit 1
fi

print_status "Verificando configuração do Git..."

# Configurar Git com valores padrão (você pode modificar estas variáveis)
GIT_NAME="UTI Board 360 Contributor"
GIT_EMAIL="contributors@example.com"

git config --global user.name "$GIT_NAME"
git config --global user.email "$GIT_EMAIL"

print_success "Configuração do Git atualizada!"

# Verificar se repositório já está inicializado
if [ ! -d ".git" ]; then
    print_status "Inicializando repositório Git..."
    git init
    print_success "Repositório Git inicializado!"
else
    echo "⚠️  Repositório Git já está inicializado."
fi

# Verificar se há mudanças para commit
if git diff --cached --quiet; then
    echo "⚠️  Não há mudanças para commit."
else
    print_status "Fazendo commit inicial..."
    git commit -m "🎉 Initial commit: UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha

✨ Funcionalidades implementadas:
- 🏥 Backend FastAPI completo com autenticação JWT
- ⚛️ Frontend React com interface dark mode
- 🔐 Sistema RBAC (Role-Based Access Control)
- 📊 Dashboard 360º para organização clínica
- 🐳 Containerização Docker
- 📝 Documentação completa

🚀 Stack:
- FastAPI + SQLAlchemy + JWT
- React 18 + TypeScript + Tailwind CSS
- Docker + Docker Compose

⚕️ Sistema desenvolvido para uso em UTI e Sala Vermelha"
    print_success "Commit inicial realizado!"
fi

# Renomear branch para main
git branch -M main

print_success "🎉 Setup do Git concluído!"
echo ""
echo "📋 Próximos passos manuais:"
echo "1. Crie um repositório no GitHub.com"
echo "2. Execute os comandos abaixo:"
echo ""
echo "# Adicionar origin (substitua seu-usuario)"
echo "git remote add origin https://github.com/seu-usuario/uti-board-360.git"
echo ""
echo "# Fazer push"
echo "git push -u origin main"
echo ""
echo "# Criar tag de versão"
echo "git tag -a v1.0.0 -m '🎉 v1.0.0 - Versão Inicial do UTI Board 360'"
echo "git push origin v1.0.0"
echo ""
echo "✨ Seu UTI Board 360 está pronto para o GitHub!"

# Mostrar resumo final
echo ""
echo "📊 Status do Repositório:"
git status --short
echo ""
echo "🔗 URLs úteis:"
echo "- Local: http://localhost:3000"
echo "- API: http://localhost:8000"
echo "- API Docs: http://localhost:8000/docs"