# UTI Board 360

Sistema de Gestão para UTI e Sala Vermelha - Dashboard estruturado para organização de informações clínicas em ambiente hospitalar crítico.

## 🏥 Sobre o Projeto

O **UTI Board 360** é uma aplicação web profissional desenvolvida especificamente para UTIs (Unidades de Terapia Intensiva) e Salas Vermelhas. O sistema tem como função principal:

- **Organizar** texto livre de evoluções/anamneses/resumos clínicos
- **Converter** informações em Dashboard 360º estruturado
- **Facilitar** passagem de plantão e visão global do caso
- **Garantir** rastreabilidade e auditoria de ações

⚠️ **Limite Ético**: O sistema **NÃO** faz suporte à decisão clínica, **NÃO** sugere condutas, doses, diagnósticos ou interpreta exames. Ele apenas organiza e estrutura o que o médico já escreveu.

## 🚀 Funcionalidades Principais

### 📊 Dashboard 360º
- **Identificação**: Paciente, unidade, leito, dia de internação, diagnóstico
- **HDA**: História da Doença Atual, sintomas principais, evolução
- **Perfil Clínico**: Comorbidades, alergias, restrições, medicações crônicas
- **Histórico Assistencial**: Falhas de extubação, complicações, colonizações
- **Antimicrobianos**: ATB vigente, anteriores, culturas, status infeccioso
- **Dispositivos**: Via aérea, acessos, datas de inserção
- **Sistemas**: Neurológico, Hemodinâmico, Respiratório, Renal, GI, Infeccioso, Hematológico
- **Exame Físico**: Pupilas, pulmões, coração, abdome, extremidades
- **Síntese Clínica**: Resumo conciso da situação
- **Plano Terapêutico**: Suporte ventilatório, hemodinâmico, renal, nutricional

### 👥 Gestão de Usuários
- **Perfis**: Médico, Enfermagem, Técnico, Admin, Visualizador
- **RBAC**: Controle de acesso baseado em papéis
- **Autenticação**: JWT com refresh tokens
- **Auditoria**: Logs completos de ações

### 🏥 Gestão Clínica
- **Pacientes**: Cadastro e histórico
- **Internações**: Controle por unidade (UTI/Sala Vermelha)
- **Timeline**: Evolução temporal da internação
- **Eventos Clínicos**: Marcos importantes (intubação, extubação, etc.)

### 📈 Relatórios e Analytics
- **Dashboard Geral**: Visão da unidade
- **Timeline**: Navegação por dias de internação
- **Logs de Auditoria**: Rastreabilidade completa

## 🛠️ Stack Tecnológica

### Backend
- **FastAPI** - Framework web moderno e rápido
- **SQLAlchemy** - ORM para banco de dados
- **PostgreSQL/SQLite** - Banco de dados (desenvolvimento)
- **Alembic** - Migrações de banco
- **JWT** - Autenticação segura
- **Python 3.11+**

### Frontend
- **React 18** - Biblioteca de interface
- **Vite** - Build tool moderno
- **TypeScript** - Tipagem estática
- **Tailwind CSS** - Framework CSS utilitário
- **React Router** - Roteamento
- **Axios** - Cliente HTTP
- **Heroicons** - Ícones

### Infraestrutura
- **Docker** - Containerização
- **Docker Compose** - Orquestração
- **PostgreSQL** - Banco de produção

## 📦 Instalação e Execução

### Pré-requisitos
- Node.js 18+ 
- Python 3.11+
- pnpm (recomendado) ou npm
- Docker (opcional)

### 1. Clone e Setup
```bash
git clone <repository-url>
cd uti-board-360
```

### 2. Backend (FastAPI)
```bash
cd backend

# Instalar dependências Python
uv pip install -r requirements.txt

# Criar banco de dados
python create_tables.py

# Criar usuário admin
python create_admin.py

# Executar servidor
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### 3. Frontend (React)
```bash
# Instalar dependências
pnpm install

# Executar em desenvolvimento
pnpm dev --host 0.0.0.0 --port 3000
```

### 4. Docker (Recomendado)
```bash
# Subir toda stack
docker-compose up -d

# Ver logs
docker-compose logs -f

# Parar
docker-compose down
```

## 🔐 Credenciais de Teste

**Usuário Admin:**
- **Email**: `admin@uti.com`
- **Senha**: `admin123`

## 🌐 URLs de Acesso

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

## 🏗️ Estrutura do Projeto

```
uti-board-360/
├── backend/                 # FastAPI Backend
│   ├── app/
│   │   ├── core/           # Configurações e segurança
│   │   ├── db/             # Configuração do banco
│   │   ├── models/         # Modelos SQLAlchemy
│   │   ├── routers/        # Rotas da API
│   │   ├── schemas/        # Schemas Pydantic
│   │   └── main.py         # Aplicação principal
│   ├── alembic/            # Migrações
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/               # React Frontend
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── hooks/          # Custom hooks
│   │   ├── lib/            # Utilitários
│   │   └── App.tsx         # Aplicação principal
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml      # Orquestração Docker
├── .env                    # Variáveis de ambiente
└── README.md
```

## 📋 Fluxo de Uso

### 1. Login
- Acesse http://localhost:3000
- Use credenciais: admin@uti.com / admin123

### 2. Dashboard Principal
- Visão geral da UTI
- Estatísticas de pacientes e internações
- Ações rápidas

### 3. Gestão de Pacientes
- Cadastrar novo paciente
- Listar pacientes existentes
- Visualizar detalhes

### 4. Internações
- Criar nova internação
- Associar paciente a leito
- Controlar alta/encerramento

### 5. Dashboards 360º
- Colar evolução clínica
- Gerar Dashboard estruturado
- Visualizar por sistemas
- Timeline de evolução

## 🔒 Segurança e Compliance

### Medidas de Segurança
- **Autenticação JWT** com refresh tokens
- **RBAC** (Role-Based Access Control)
- **HTTPS** obrigatório em produção
- **CORS** configurado adequadamente
- **Logs de auditoria** completos
- **Hash de senhas** com bcrypt

### LGPD Compliance
- **Minimização de dados** pessoais
- **Logs sem dados sensíveis**
- **Rastreabilidade** de acessos
- **Controle de acesso** por perfil
- **Auditoria** completa de ações

### Limitações Éticas
- ❌ **NÃO** sugere diagnósticos
- ❌ **NÃO** recomenda condutas
- ❌ **NÃO** interpreta exames
- ❌ **NÃO** faz prescrições
- ✅ **APENAS** organiza informações existentes

## 🧪 Testes

### Backend
```bash
cd backend
python -m pytest tests/
```

### Frontend
```bash
pnpm test
```

### Sistema Completo
```bash
./test-system.sh
```

## 📈 Monitoramento

### Logs
- **Backend**: Logs estruturados em JSON
- **Frontend**: Console logs e error boundaries
- **Docker**: `docker-compose logs -f`

### Métricas
- **API**: Endpoints de health check
- **Database**: Conexões e performance
- **Frontend**: Loading states e error handling

## 🚀 Deploy em Produção

### Docker
```bash
# Build para produção
docker-compose -f docker-compose.prod.yml build

# Deploy
docker-compose -f docker-compose.prod.yml up -d
```

### Variáveis de Ambiente
```bash
# Backend
POSTGRES_SERVER=your-db-host
SECRET_KEY=your-super-secret-key
BACKEND_CORS_ORIGINS=["https://your-domain.com"]

# Frontend  
NEXT_PUBLIC_API_BASE_URL=https://your-api-domain.com/api/v1
```

### VPS/Servidor
1. Configure VPS com Docker
2. Clone repositório
3. Configure .env com variáveis de produção
4. Execute `docker-compose up -d`
5. Configure Nginx/Traefik como proxy reverso
6. Configure SSL com Let's Encrypt

## 🤝 Contribuição

1. Fork o projeto
2. Crie branch para feature (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova funcionalidade'`)
4. Push para branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob licença MIT. Veja arquivo [LICENSE](LICENSE) para detalhes.

## 👨‍💻 Autor

**MiniMax Agent**
- Desenvolvimento Full-Stack
- Especialista em Sistemas Médicos Críticos
- Arquitetura Escalável e Segura

## 🏥 Ambiente Hospitalar

Este sistema foi desenvolvido especificamente para uso em:
- **UTIs** (Unidades de Terapia Intensiva)
- **Salas Vermelhas** (Emergência)
- **Centros Cirúrgicos**
- **Unidades de Cuidados Intensivos**

### Considerações Especiais
- **Interface otimizada** para leitura rápida
- **Modo escuro** para ambientes com pouca luz
- **Responsivo** para tablets beira-leito
- **Performance** otimizada para redes hospitalares
- **Segurança** de nível médico-hospitalar

---

**⚕️ Sistema desenvolvido com foco na segurança do paciente e eficiência operacional em ambiente hospitalar crítico.**