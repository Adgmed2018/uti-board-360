#!/bin/bash

# 🚀 UTI Board 360 - Setup Automatizado do GitHub
# Este script automatiza a configuração do Git e GitHub

set -e  # Parar em caso de erro

echo "🩺 UTI Board 360 - Setup do GitHub"
echo "=================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para print colorido
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar se estamos no diretório correto
if [ ! -f "README.md" ] || [ ! -f "docker-compose.yml" ]; then
    print_error "Este script deve ser executado na raiz do projeto UTI Board 360"
    exit 1
fi

# Verificar se Git está instalado
if ! command -v git &> /dev/null; then
    print_error "Git não está instalado. Por favor, instale o Git primeiro."
    exit 1
fi

print_status "Verificando configuração do Git..."

# Configurar Git se necessário
read -p "Digite seu nome para Git (será usado nos commits): " git_name
read -p "Digite seu email para Git: " git_email

git config --global user.name "$git_name"
git config --global user.email "$git_email"

print_success "Configuração do Git atualizada!"

# Verificar se repositório já está inicializado
if [ ! -d ".git" ]; then
    print_status "Inicializando repositório Git..."
    git init
    print_success "Repositório Git inicializado!"
else
    print_warning "Repositório Git já está inicializado."
fi

# Adicionar arquivos
print_status "Adicionando arquivos ao Git..."
git add .

# Verificar se há mudanças para commit
if git diff --cached --quiet; then
    print_warning "Não há mudanças para commit."
else
    print_status "Fazendo commit inicial..."
    git commit -m "🎉 Initial commit: UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha

✨ Funcionalidades implementadas:
- 🏥 Backend FastAPI completo com autenticação JWT
- ⚛️ Frontend React com interface dark mode
- 🔐 Sistema RBAC (Role-Based Access Control)
- 📊 Dashboard 360º para organização clínica
- 🐳 Containerização Docker
- 📝 Documentação completa

🚀 Stack:
- FastAPI + SQLAlchemy + JWT
- React 18 + TypeScript + Tailwind CSS
- Docker + Docker Compose

⚕️ Sistema desenvolvido para uso em UTI e Sala Vermelha"
    print_success "Commit inicial realizado!"
fi

# Renomear branch para main
git branch -M main

# Verificar se GitHub CLI está disponível
if command -v gh &> /dev/null; then
    print_status "GitHub CLI detectado!"
    
    # Verificar se está autenticado
    if gh auth status &> /dev/null; then
        print_success "Já autenticado no GitHub!"
        
        # Perguntar se quer criar repositório
        read -p "Deseja criar o repositório no GitHub agora? (y/N): " create_repo
        
        if [ "$create_repo" = "y" ] || [ "$create_repo" = "Y" ]; then
            read -p "Digite o nome do repositório (padrão: uti-board-360): " repo_name
            repo_name=${repo_name:-uti-board-360}
            
            print_status "Criando repositório $repo_name..."
            
            gh repo create "$repo_name" \
                --public \
                --description "🏥 UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha. Dashboard estruturado para organização de informações clínicas em ambiente hospitalar crítico. NÃO faz suporte à decisão clínica, apenas organiza informações existentes." \
                --source=. \
                --remote=origin \
                --push
            
            print_success "Repositório criado e código enviado!"
            
            # Criar tag de versão
            print_status "Criando tag de versão..."
            git tag -a v1.0.0 -m "🎉 v1.0.0 - Versão Inicial do UTI Board 360

✨ Funcionalidades:
- Sistema de autenticação JWT completo
- Dashboard principal com estatísticas
- API REST FastAPI com validação
- Interface React dark mode
- RBAC por perfis de usuário
- Containerização Docker
- Documentação completa"
            
            git push origin v1.0.0
            print_success "Tag v1.0.0 criada e enviada!"
            
        fi
    else
        print_warning "GitHub CLI detectado, mas não está autenticado."
        print_status "Execute: gh auth login"
    fi
else
    print_warning "GitHub CLI não está instalado."
    echo ""
    echo "📝 Para configurar manualmente:"
    echo "1. Crie um repositório no GitHub.com"
    echo "2. Execute:"
    echo "   git remote add origin https://github.com/seu-usuario/uti-board-360.git"
    echo "   git push -u origin main"
    echo ""
fi

# Mostrar status final
echo ""
print_success "🎉 Setup do Git concluído!"
echo ""
echo "📋 Resumo:"
echo "- ✅ Repositório Git configurado"
echo "- ✅ Commit inicial realizado"
echo "- ✅ Branch 'main' configurada"
echo ""
if command -v gh &> /dev/null && gh auth status &> /dev/null; then
    if [ ! -z "$repo_name" ]; then
        echo "- ✅ Repositório GitHub criado: https://github.com/$git_name/$repo_name"
        echo "- ✅ Código enviado para o GitHub"
        echo "- ✅ Tag v1.0.0 criada"
    fi
fi
echo ""
echo "🔗 URLs úteis:"
echo "- Local: http://localhost:3000"
echo "- API: http://localhost:8000"
echo "- API Docs: http://localhost:8000/docs"
echo ""
echo "🔐 Credenciais de teste:"
echo "- Email: admin@uti.com"
echo "- Senha: admin123"
echo ""
echo "📚 Próximos passos:"
echo "1. Configure o repositório como privado (se necessário)"
echo "2. Adicione colaboradores no GitHub"
echo "3. Configure GitHub Pages para documentação"
echo "4. Configure GitHub Actions para CI/CD"
echo ""
echo "✨ Seu UTI Board 360 está pronto para o GitHub!"

# Abrir GitHub no navegador (se gh estiver disponível e repo criado)
if command -v gh &> /dev/null && gh auth status &> /dev/null && [ ! -z "$repo_name" ]; then
    read -p "Deseja abrir o repositório no navegador? (Y/n): " open_browser
    if [ "$open_browser" != "n" ] && [ "$open_browser" != "N" ]; then
        gh repo view --web
    fi
fi