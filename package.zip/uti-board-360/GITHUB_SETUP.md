# 🚀 Guia para Colocar UTI Board 360 no GitHub

Este guia passo-a-passo irá ajudá-lo a colocar o projeto UTI Board 360 no GitHub.

## 📋 Pré-requisitos

1. **Conta GitHub**: Crie uma conta em [github.com](https://github.com) se ainda não tiver
2. **Git instalado**: Certifique-se de que o Git está instalado no seu sistema
3. **GitHub CLI** (opcional mas recomendado): Instale via `brew install gh` (macOS) ou `choco install gh` (Windows)

## 🔧 Configuração Inicial do Git

Execute os seguintes comandos na raiz do projeto:

```bash
# Navegar para o diretório do projeto
cd uti-board-360

# Configurar usuário Git (substitua pelas suas informações)
git config --global user.name "Seu Nome"
git config --global user.email "seu.email@exemplo.com"

# Inicializar repositório Git
git init

# Adicionar todos os arquivos
git add .

# Fazer o commit inicial
git commit -m "🎉 Initial commit: UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha

✨ Funcionalidades implementadas:
- 🏥 Backend FastAPI completo com autenticação JWT
- ⚛️ Frontend React com interface dark mode
- 🔐 Sistema RBAC (Role-Based Access Control)
- 📊 Dashboard 360º para organização clínica
- 🐳 Containerização Docker
- 📝 Documentação completa

🚀 Stack:
- FastAPI + SQLAlchemy + JWT
- React 18 + TypeScript + Tailwind CSS
- Docker + Docker Compose

⚕️ Sistema desenvolvido para uso em UTI e Sala Vermelha"
```

## 🌐 Criar Repositório no GitHub

### Opção 1: Via GitHub CLI (Recomendado)

```bash
# Fazer login no GitHub (se não estiver logado)
gh auth login

# Criar repositório privado (recomendado para projeto hospitalar)
gh repo create uti-board-360 --public --description "🏥 UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha. Dashboard estruturado para organização de informações clínicas em ambiente hospitalar crítico. NÃO faz suporte à decisão clínica, apenas organiza informações existentes."

# Adicionar origin e fazer push
git remote add origin https://github.com/seu-usuario/uti-board-360.git
git branch -M main
git push -u origin main
```

### Opção 2: Via Interface Web do GitHub

1. Acesse [GitHub.com](https://github.com) e faça login
2. Clique no botão "+" no canto superior direito
3. Selecione "New repository"
4. Preencha os dados:
   - **Repository name**: `uti-board-360`
   - **Description**: `🏥 UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha. Dashboard estruturado para organização de informações clínicas em ambiente hospitalar crítico.`
   - **Visibility**: Private (recomendado) ou Public
   - **❌ NÃO** marque "Add a README file" (já temos um)
5. Clique em "Create repository"

Em seguida, execute:

```bash
# Adicionar origin
git remote add origin https://github.com/seu-usuario/uti-board-360.git

# Renomear branch para main (padrão atual)
git branch -M main

# Fazer push inicial
git push -u origin main
```

## 🏷️ Criar Tags de Versão

```bash
# Criar tag para a versão inicial
git tag -a v1.0.0 -m "🎉 v1.0.0 - Versão Inicial do UTI Board 360

✨ Funcionalidades:
- Sistema de autenticação JWT completo
- Dashboard principal com estatísticas
- API REST FastAPI com validação
- Interface React dark mode
- RBAC por perfis de usuário
- Containerização Docker
- Documentação completa"

# Push da tag
git push origin v1.0.0
```

## 🔒 Configurações de Segurança

### 1. Configurar .gitignore (já incluído)

O arquivo `.gitignore` já está configurado para:
- ❌ Excluir arquivos de ambiente (`.env`)
- ❌ Excluir banco de dados local (`*.db`)
- ❌ Excluir dependências (`node_modules/`, `__pycache__/`)
- ❌ Excluir arquivos de IDE
- ❌ Excluir arquivos do sistema operacional

### 2. Configurar Secrets (se usar GitHub Actions)

No GitHub, vá para Settings > Secrets and variables > Actions e adicione:
- `DOCKER_USERNAME`
- `DOCKER_PASSWORD`
- `DEPLOY_HOST` (se usar deploy automatizado)

### 3. Configurar Branch Protection

1. Vá para Settings > Branches
2. Adicione regra para branch `main`
3. Requer pull request reviews
4. Requer status checks

## 📋 Próximos Passos

### 1. Configurar GitHub Pages (Opcional)

Se quiser hospedar a documentação:
```bash
# Instalar docsify ou similar para documentação
pnpm add -D docsify-cli

# Configurar GitHub Pages para branch gh-pages
```

### 2. Configurar GitHub Actions (Opcional)

Criar `.github/workflows/ci.yml` para:
- Testes automatizados
- Build e deploy
- Linting de código

### 3. Configurar Issues e Projects

1. Habilitar Issues no repositório
2. Criar Projects para roadmap
3. Configurar Labels e Milestones

### 4. Configurar Wiki e Releases

1. Usar o README.md como base para Wiki
2. Criar Releases para versões
3. Adicionar screenshots e demonstrações

## 🔗 Links Úteis

- **Repositório**: https://github.com/seu-usuario/uti-board-360
- **Demo Local**: http://localhost:3000
- **API Docs**: http://localhost:8000/docs

## ⚠️ Observações Importantes

### Segurança
- **❌ NUNCA** commit arquivos `.env` com senhas reais
- **✅ SEMPRE** use variables de ambiente para produção
- **🔒** Configure repositório como privado se contiver dados sensíveis

### Licenciamento
- Considere adicionar uma licença (MIT é comum)
- Adicione LICENSE file

### Documentação
- Mantenha README.md atualizado
- Adicione screenshots do sistema
- Documente APIs com exemplos

---

**🎉 Seu UTI Board 360 agora está no GitHub e pronto para colaboração!**