#!/bin/bash

echo "🩺 UTI Board 360 - Sistema de Gestão para UTI e Sala Vermelha"
echo "=========================================================="
echo ""

echo "📊 Backend Status:"
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend FastAPI rodando em http://localhost:8000"
    echo "   📋 API Docs: http://localhost:8000/docs"
    echo "   🔍 Health Check: http://localhost:8000/health"
else
    echo "❌ Backend não está rodando"
    echo "   Para iniciar: cd backend && python -m uvicorn app.main:app --host 0.0.0.0 --port 8000"
fi

echo ""
echo "🌐 Frontend Status:"
if curl -s -I http://localhost:3000 | head -n1 | grep -q "200 OK"; then
    echo "✅ Frontend React rodando em http://localhost:3000"
else
    echo "❌ Frontend não está rodando"
    echo "   Para iniciar: pnpm dev --host 0.0.0.0 --port 3000"
fi

echo ""
echo "🔐 Credenciais de Teste:"
echo "   📧 Email: admin@uti.com"
echo "   🔑 Senha: admin123"

echo ""
echo "🐳 Docker Status:"
if command -v docker &> /dev/null && docker ps | grep -q "uti_board"; then
    echo "✅ Containers Docker rodando"
    docker ps --filter "name=uti_board" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
else
    echo "ℹ️  Docker não está rodando ou containers não iniciados"
    echo "   Para iniciar com Docker: docker-compose up -d"
fi

echo ""
echo "📝 Próximos Passos:"
echo "1. Acesse http://localhost:3000 no navegador"
echo "2. Faça login com as credenciais acima"
echo "3. Explore o dashboard e navegue pelo sistema"
echo "4. Teste a criação de pacientes, internações e dashboards"

echo ""
echo "🔧 Comandos Úteis:"
echo "   Backend:  cd backend && python -m uvicorn app.main:app --reload"
echo "   Frontend: pnpm dev"
echo "   Docker:   docker-compose up -d"
echo "   Logs:     docker-compose logs -f"

echo ""
echo "✨ Sistema pronto para uso em ambiente de desenvolvimento!"