from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.db.session import get_db
from app.schemas.patient import PatientCreate, PatientUpdate, PatientOut
from app.models.patient import Patient
from app.models.user import User, UserRole
from app.routers.deps import get_current_user
from app.models.log import Log

router = APIRouter(prefix="/patients", tags=["patients"])

@router.post("/", response_model=PatientOut)
def create_patient(
    patient_in: PatientCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    db_patient = Patient(**patient_in.dict())
    db.add(db_patient)
    db.commit()
    db.refresh(db_patient)
    
    # Log da criação
    log_entry = Log(
        user_id=current_user.id,
        action="CREATE_PATIENT",
        entity_type="PATIENT",
        entity_id=db_patient.id,
        details={"name": db_patient.name}
    )
    db.add(log_entry)
    db.commit()
    
    return db_patient

@router.get("/", response_model=list[PatientOut])
def get_patients(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    skip: int = 0,
    limit: int = 100,
    search: str | None = None
):
    query = db.query(Patient).filter(Patient.active == "true")
    
    if search:
        query = query.filter(
            or_(
                Patient.name.ilike(f"%{search}%"),
                Patient.medical_record_number.ilike(f"%{search}%")
            )
        )
    
    patients = query.offset(skip).limit(limit).all()
    return patients

@router.get("/{patient_id}", response_model=PatientOut)
def get_patient(
    patient_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    patient = db.query(Patient).filter(Patient.id == patient_id, Patient.active == "true").first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Log do acesso
    log_entry = Log(
        user_id=current_user.id,
        action="VIEW_PATIENT",
        entity_type="PATIENT",
        entity_id=patient_id
    )
    db.add(log_entry)
    db.commit()
    
    return patient

@router.put("/{patient_id}", response_model=PatientOut)
def update_patient(
    patient_id: str,
    patient_in: PatientUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Verificar permissões (apenas médicos podem editar dados clínicos)
    if current_user.role not in [UserRole.MEDICO, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    for field, value in patient_in.dict(exclude_unset=True).items():
        setattr(patient, field, value)
    
    db.commit()
    db.refresh(patient)
    
    return patient