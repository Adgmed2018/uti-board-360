from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime, timedelta
from app.db.session import get_db
from app.schemas.log import LogOut
from app.models.log import Log
from app.models.user import User, UserRole
from app.routers.deps import get_current_user, get_current_active_superuser

router = APIRouter(prefix="/logs", tags=["logs"])

@router.get("/", response_model=list[LogOut])
def get_logs(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_superuser),
    skip: int = 0,
    limit: int = 100,
    user_id: str | None = None,
    action: str | None = None,
    entity_type: str | None = None,
    days: int = 7
):
    query = db.query(Log)
    
    # Filtros
    if user_id:
        query = query.filter(Log.user_id == user_id)
    
    if action:
        query = query.filter(Log.action == action)
    
    if entity_type:
        query = query.filter(Log.entity_type == entity_type)
    
    # Filtro por data (últimos N dias)
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    query = query.filter(Log.timestamp >= cutoff_date)
    
    logs = query.order_by(desc(Log.timestamp)).offset(skip).limit(limit).all()
    
    return logs

@router.get("/patient/{patient_id}", response_model=list[LogOut])
def get_patient_access_logs(
    patient_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_superuser),
    limit: int = 50
):
    # Buscar logs relacionados ao paciente
    logs = db.query(Log).filter(
        Log.entity_type == "PATIENT",
        Log.entity_id == patient_id
    ).order_by(desc(Log.timestamp)).limit(limit).all()
    
    return logs

@router.get("/statistics")
def get_log_statistics(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_superuser),
    days: int = 7
):
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    # Estatísticas por ação
    actions_stats = db.query(Log.action, db.func.count(Log.id)).filter(
        Log.timestamp >= cutoff_date
    ).group_by(Log.action).all()
    
    # Estatísticas por usuário
    users_stats = db.query(Log.user_id, db.func.count(Log.id)).filter(
        Log.timestamp >= cutoff_date,
        Log.user_id.isnot(None)
    ).group_by(Log.user_id).all()
    
    # Total de logs no período
    total_logs = db.query(Log).filter(Log.timestamp >= cutoff_date).count()
    
    return {
        "period_days": days,
        "total_logs": total_logs,
        "actions_breakdown": dict(actions_stats),
        "users_breakdown": dict(users_stats)
    }