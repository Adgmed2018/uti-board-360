from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.admission import AdmissionCreate, AdmissionUpdate, AdmissionOut
from app.models.admission import Admission
from app.models.patient import Patient
from app.models.user import User, UserRole
from app.routers.deps import get_current_user
from app.models.log import Log

router = APIRouter(prefix="/admissions", tags=["admissions"])

@router.post("/", response_model=AdmissionOut)
def create_admission(
    admission_in: AdmissionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Verificar se o paciente existe
    patient = db.query(Patient).filter(Patient.id == admission_in.patient_id, Patient.active == "true").first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Verificar se o leito já está ocupado na mesma unidade
    existing_admission = db.query(Admission).filter(
        Admission.bed_number == admission_in.bed_number,
        Admission.unit == admission_in.unit,
        Admission.discharge_date.is_(None)
    ).first()
    
    if existing_admission:
        raise HTTPException(status_code=400, detail="Bed already occupied")
    
    # Verificar permissões
    if current_user.role not in [UserRole.MEDICO, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    db_admission = Admission(
        **admission_in.dict(),
        created_by=current_user.id
    )
    db.add(db_admission)
    db.commit()
    db.refresh(db_admission)
    
    # Log da criação
    log_entry = Log(
        user_id=current_user.id,
        action="CREATE_ADMISSION",
        entity_type="ADMISSION",
        entity_id=db_admission.id,
        details={"patient_id": admission_in.patient_id, "bed": admission_in.bed_number}
    )
    db.add(log_entry)
    db.commit()
    
    return db_admission

@router.get("/{admission_id}", response_model=AdmissionOut)
def get_admission(
    admission_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    admission = db.query(Admission).filter(Admission.id == admission_id).first()
    if not admission:
        raise HTTPException(status_code=404, detail="Admission not found")
    
    return admission

@router.get("/patient/{patient_id}", response_model=list[AdmissionOut])
def get_patient_admissions(
    patient_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    admissions = db.query(Admission).filter(
        Admission.patient_id == patient_id
    ).order_by(Admission.admission_date.desc()).all()
    
    return admissions

@router.get("/active/unit/{unit}", response_model=list[AdmissionOut])
def get_active_admissions_by_unit(
    unit: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    admissions = db.query(Admission).filter(
        Admission.unit == unit,
        Admission.discharge_date.is_(None)
    ).order_by(Admission.bed_number).all()
    
    return admissions

@router.put("/{admission_id}", response_model=AdmissionOut)
def update_admission(
    admission_id: str,
    admission_in: AdmissionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    admission = db.query(Admission).filter(Admission.id == admission_id).first()
    if not admission:
        raise HTTPException(status_code=404, detail="Admission not found")
    
    # Verificar permissões
    if current_user.role not in [UserRole.MEDICO, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    # Se está liberando o leito (discharge_date), verificar se não há dashboards pendentes
    if admission_in.discharge_date and not admission.discharge_date:
        dashboards = db.query(Dashboard).filter(
            Dashboard.admission_id == admission_id,
            Dashboard.created_at > admission_in.discharge_date
        ).count()
        
        if dashboards > 0:
            raise HTTPException(status_code=400, detail="Cannot discharge: there are dashboards created after the discharge date")
    
    for field, value in admission_in.dict(exclude_unset=True).items():
        setattr(admission, field, value)
    
    db.commit()
    db.refresh(admission)
    
    return admission