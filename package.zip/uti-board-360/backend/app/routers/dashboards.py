from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.dashboard import DashboardCreate, DashboardUpdate, DashboardOut
from app.models.dashboard import Dashboard
from app.models.admission import Admission
from app.models.user import User, UserRole
from app.routers.deps import get_current_user
from app.models.log import Log

router = APIRouter(prefix="/dashboards", tags=["dashboards"])

@router.post("/", response_model=DashboardOut)
def create_dashboard(
    dashboard_in: DashboardCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Verificar se a internação existe e está ativa
    admission = db.query(Admission).filter(
        Admission.id == dashboard_in.admission_id,
        Admission.discharge_date.is_(None)
    ).first()
    
    if not admission:
        raise HTTPException(status_code=404, detail="Active admission not found")
    
    # Verificar permissões (apenas médicos podem criar dashboards)
    if current_user.role not in [UserRole.MEDICO, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    # Verificar se já existe dashboard para esta data
    existing_dashboard = db.query(Dashboard).filter(
        Dashboard.admission_id == dashboard_in.admission_id,
        Dashboard.reference_date == dashboard_in.reference_date
    ).first()
    
    if existing_dashboard:
        raise HTTPException(status_code=400, detail="Dashboard already exists for this date")
    
    db_dashboard = Dashboard(
        **dashboard_in.dict(),
        created_by=current_user.id
    )
    db.add(db_dashboard)
    db.commit()
    db.refresh(db_dashboard)
    
    # Log da criação
    log_entry = Log(
        user_id=current_user.id,
        action="CREATE_DASHBOARD",
        entity_type="DASHBOARD",
        entity_id=db_dashboard.id,
        details={
            "admission_id": dashboard_in.admission_id,
            "reference_date": str(dashboard_in.reference_date),
            "type": dashboard_in.type
        }
    )
    db.add(log_entry)
    db.commit()
    
    return db_dashboard

@router.get("/{dashboard_id}", response_model=DashboardOut)
def get_dashboard(
    dashboard_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    dashboard = db.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
    if not dashboard:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    
    return dashboard

@router.get("/admission/{admission_id}", response_model=list[DashboardOut])
def get_admission_dashboards(
    admission_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    dashboards = db.query(Dashboard).filter(
        Dashboard.admission_id == admission_id
    ).order_by(Dashboard.reference_date).all()
    
    return dashboards

@router.put("/{dashboard_id}", response_model=DashboardOut)
def update_dashboard(
    dashboard_id: str,
    dashboard_in: DashboardUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    dashboard = db.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
    if not dashboard:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    
    # Verificar permissões
    if current_user.role not in [UserRole.MEDICO, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    # Verificar se o usuário pode editar este dashboard
    if current_user.role != UserRole.ADMIN and dashboard.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="Can only edit your own dashboards")
    
    for field, value in dashboard_in.dict(exclude_unset=True).items():
        setattr(dashboard, field, value)
    
    db.commit()
    db.refresh(dashboard)
    
    # Log da atualização
    log_entry = Log(
        user_id=current_user.id,
        action="UPDATE_DASHBOARD",
        entity_type="DASHBOARD",
        entity_id=dashboard_id,
        details={"updated_fields": list(dashboard_in.dict(exclude_unset=True).keys())}
    )
    db.add(log_entry)
    db.commit()
    
    return dashboard

@router.get("/unit/{unit}/active", response_model=list[DashboardOut])
def get_active_dashboards_by_unit(
    unit: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Buscar dashboards das internações ativas da unidade
    dashboards = db.query(Dashboard).join(Admission).filter(
        Admission.unit == unit,
        Admission.discharge_date.is_(None),
        Dashboard.reference_date >= Admission.admission_date
    ).order_by(Admission.bed_number, Dashboard.reference_date.desc()).all()
    
    return dashboards