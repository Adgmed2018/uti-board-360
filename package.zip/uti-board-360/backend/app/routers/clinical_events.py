from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.clinical_event import ClinicalEventCreate, ClinicalEventOut
from app.models.clinical_event import ClinicalEvent
from app.models.admission import Admission
from app.models.user import User, UserRole
from app.routers.deps import get_current_user
from app.models.log import Log

router = APIRouter(prefix="/clinical-events", tags=["clinical-events"])

@router.post("/", response_model=ClinicalEventOut)
def create_clinical_event(
    event_in: ClinicalEventCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Verificar se a internação existe
    admission = db.query(Admission).filter(Admission.id == event_in.admission_id).first()
    if not admission:
        raise HTTPException(status_code=404, detail="Admission not found")
    
    # Verificar permissões
    if current_user.role not in [UserRole.MEDICO, UserRole.ENFERMAGEM, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    db_event = ClinicalEvent(
        **event_in.dict(),
        created_by=current_user.id
    )
    db.add(db_event)
    db.commit()
    db.refresh(db_event)
    
    # Log da criação
    log_entry = Log(
        user_id=current_user.id,
        action="CREATE_CLINICAL_EVENT",
        entity_type="CLINICAL_EVENT",
        entity_id=db_event.id,
        details={
            "admission_id": event_in.admission_id,
            "event_type": event_in.event_type
        }
    )
    db.add(log_entry)
    db.commit()
    
    return db_event

@router.get("/admission/{admission_id}", response_model=list[ClinicalEventOut])
def get_admission_events(
    admission_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    events = db.query(ClinicalEvent).filter(
        ClinicalEvent.admission_id == admission_id
    ).order_by(ClinicalEvent.event_date).all()
    
    return events

@router.delete("/{event_id}")
def delete_clinical_event(
    event_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    event = db.query(ClinicalEvent).filter(ClinicalEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    # Verificar permissões
    if current_user.role not in [UserRole.MEDICO, UserRole.ADMIN]:
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    # Verificar se o usuário pode deletar este evento
    if current_user.role != UserRole.ADMIN and event.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="Can only delete your own events")
    
    db.delete(event)
    db.commit()
    
    # Log da deleção
    log_entry = Log(
        user_id=current_user.id,
        action="DELETE_CLINICAL_EVENT",
        entity_type="CLINICAL_EVENT",
        entity_id=event_id
    )
    db.add(log_entry)
    db.commit()
    
    return {"message": "Event deleted successfully"}