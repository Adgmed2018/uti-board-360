from datetime import datetime, date
from pydantic import BaseModel
from typing import Optional

class PatientBase(BaseModel):
    name: str
    date_of_birth: Optional[date] = None
    sex: Optional[str] = None
    medical_record_number: Optional[str] = None
    allergies: Optional[str] = None
    notes: Optional[str] = None
    active: str = "true"

class PatientCreate(PatientBase):
    pass

class PatientUpdate(BaseModel):
    name: Optional[str] = None
    date_of_birth: Optional[date] = None
    sex: Optional[str] = None
    medical_record_number: Optional[str] = None
    allergies: Optional[str] = None
    notes: Optional[str] = None
    active: Optional[str] = None

class PatientOut(PatientBase):
    id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True