from datetime import datetime, date
from pydantic import BaseModel
from typing import Any, Optional

# Schema para dados estruturados do Dashboard 360º
class DashboardData(BaseModel):
    identificacao: dict[str, Any]
    hda: dict[str, Any]
    perfil_clinico: dict[str, Any]
    historico_assistencial: dict[str, Any]
    antimicrobianos: dict[str, Any]
    dispositivos: dict[str, Any]
    sistemas: dict[str, Any]
    exame_fisico: dict[str, Any]
    sintese_clinica: Optional[str] = None
    impressao_clinica_original: Optional[str] = None
    plano_terapeutico: dict[str, Any]

class DashboardBase(BaseModel):
    admission_id: str
    reference_date: date
    day_label: Optional[str] = None
    type: str = "UTI"
    raw_text: Optional[str] = None
    structured_data: Optional[DashboardData] = None
    critical_status: str = "stable"

class DashboardCreate(DashboardBase):
    pass

class DashboardUpdate(BaseModel):
    reference_date: Optional[date] = None
    day_label: Optional[str] = None
    type: Optional[str] = None
    raw_text: Optional[str] = None
    structured_data: Optional[DashboardData] = None
    critical_status: Optional[str] = None

class DashboardOut(DashboardBase):
    id: str
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True