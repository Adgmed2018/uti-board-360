from datetime import datetime
from pydantic import BaseModel
from typing import Optional

class AdmissionBase(BaseModel):
    patient_id: str
    bed_number: str
    unit: str
    main_diagnosis: Optional[str] = None
    admission_reason: Optional[str] = None
    admission_date: Optional[datetime] = None

class AdmissionCreate(AdmissionBase):
    pass

class AdmissionUpdate(BaseModel):
    bed_number: Optional[str] = None
    unit: Optional[str] = None
    main_diagnosis: Optional[str] = None
    admission_reason: Optional[str] = None
    discharge_date: Optional[datetime] = None

class AdmissionOut(AdmissionBase):
    id: str
    discharge_date: Optional[datetime]
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True