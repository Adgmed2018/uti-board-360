from datetime import datetime
from pydantic import BaseModel
from typing import Optional

class ClinicalEventBase(BaseModel):
    admission_id: str
    event_type: str
    event_date: Optional[datetime] = None
    description: Optional[str] = None
    details: Optional[str] = None

class ClinicalEventCreate(ClinicalEventBase):
    pass

class ClinicalEventOut(ClinicalEventBase):
    id: str
    created_by: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True