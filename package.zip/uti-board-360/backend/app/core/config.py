from pydantic import AnyUrl
from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List, Union

class Settings(BaseSettings):
    PROJECT_NAME: str = "UTI Board 360 API"
    API_V1_STR: str = "/api/v1"
    
    # Database
    POSTGRES_SERVER: str = "localhost"
    POSTGRES_PORT: str = "5432"
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DB: str = "uti_board_360"
    
    # Auth / JWT
    SECRET_KEY: str = "CHANGE_ME_SUPER_SECRET_KEY_CHANGE_THIS_IN_PRODUCTION"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    ALGORITHM: str = "HS256"
    
    # CORS
    BACKEND_CORS_ORIGINS: List[Union[AnyUrl, str]] = ["http://localhost:3000", "http://localhost:5173"]
    
    class Config:
        case_sensitive = True
        env_file = ".env"
        env_file_encoding = "utf-8"

@lru_cache
def get_settings() -> Settings:
    return Settings()

settings = get_settings()