from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.routers import auth as auth_router
from app.routers import users as users_router
from app.routers import patients as patients_router
from app.routers import admissions as admissions_router
from app.routers import dashboards as dashboards_router
from app.routers import clinical_events as clinical_events_router
from app.routers import logs as logs_router

def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.PROJECT_NAME,
        description="Sistema de Gestão para UTI e Sala Vermelha",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc"
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.BACKEND_CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include routers
    api_prefix = settings.API_V1_STR
    app.include_router(auth_router.router, prefix=api_prefix)
    app.include_router(users_router.router, prefix=api_prefix)
    app.include_router(patients_router.router, prefix=api_prefix)
    app.include_router(admissions_router.router, prefix=api_prefix)
    app.include_router(dashboards_router.router, prefix=api_prefix)
    app.include_router(clinical_events_router.router, prefix=api_prefix)
    app.include_router(logs_router.router, prefix=api_prefix)
    
    @app.get("/")
    def root():
        return {
            "message": "UTI Board 360 API",
            "version": "1.0.0",
            "status": "online"
        }
    
    @app.get("/health")
    def health_check():
        return {"status": "healthy"}
    
    return app

app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)