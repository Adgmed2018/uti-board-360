import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base

class Admission(Base):
    __tablename__ = "admissions"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    bed_number = Column(String, nullable=False)  # Número do leito
    unit = Column(String, nullable=False)  # "UTI" ou "SALA_VERMELHA"
    admission_date = Column(DateTime, default=datetime.utcnow, nullable=False)
    discharge_date = Column(DateTime, nullable=True)
    main_diagnosis = Column(Text, nullable=True)  # Diagnóstico principal
    admission_reason = Column(Text, nullable=True)  # Motivo da internação
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    patient = relationship("Patient", back_populates="admissions")
    dashboards = relationship("Dashboard", back_populates="admission")
    clinical_events = relationship("ClinicalEvent", back_populates="admission")