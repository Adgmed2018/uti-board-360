import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from app.db.base import Base

class Log(Base):
    __tablename__ = "logs"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id"), nullable=True)
    action = Column(String, nullable=False)  # "LOGIN", "CREATE_DASHBOARD", "VIEW_PATIENT", etc.
    entity_type = Column(String, nullable=True)  # "PATIENT", "ADMISSION", "DASHBOARD"
    entity_id = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    details = Column(Text, nullable=True)  # Dados adicionais da ação (JSON como texto)
    ip_address = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)