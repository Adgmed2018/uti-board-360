import uuid
from datetime import datetime, date
from sqlalchemy import Column, String, DateTime, Date, Text
from sqlalchemy.orm import relationship
from app.db.base import Base

class Patient(Base):
    __tablename__ = "patients"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    date_of_birth = Column(Date, nullable=True)
    sex = Column(String, nullable=True)  # "M", "F"
    medical_record_number = Column(String, nullable=True)  # Prontuário Hospitalar
    allergies = Column(Text, nullable=True)  # Lista de alergias
    notes = Column(Text, nullable=True)  # Observações importantes (ex: Testemunha de Jeová)
    active = Column(String, default="true", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    admissions = relationship("Admission", back_populates="patient")