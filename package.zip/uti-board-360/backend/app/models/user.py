import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Enum, Text
from app.db.base import Base
import enum

class UserRole(str, enum.Enum):
    MEDICO = "MEDICO"
    ENFERMAGEM = "ENFERMAGEM"
    TECNICO = "TECNICO"
    ADMIN = "ADMIN"
    VISUALIZADOR = "VISUALIZADOR"

class User(Base):
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(Enum(UserRole), nullable=False, default=UserRole.MEDICO)
    active = Column(String, default="true", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, nullable=False)