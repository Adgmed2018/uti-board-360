import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base

class ClinicalEvent(Base):
    __tablename__ = "clinical_events"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    admission_id = Column(String, ForeignKey("admissions.id"), nullable=False)
    event_type = Column(String, nullable=False)  # "admission", "extubation", "intubation", "dialysis", etc.
    event_date = Column(DateTime, default=datetime.utcnow, nullable=False)
    description = Column(Text, nullable=True)
    details = Column(Text, nullable=True)  # Detalhes específicos do evento
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    admission = relationship("Admission", back_populates="clinical_events")