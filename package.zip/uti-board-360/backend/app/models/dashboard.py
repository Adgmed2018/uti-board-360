import uuid
from datetime import datetime, date
from sqlalchemy import Column, String, DateTime, Date, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base

class Dashboard(Base):
    __tablename__ = "dashboards"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    admission_id = Column(String, ForeignKey("admissions.id"), nullable=False)
    reference_date = Column(Date, nullable=False)  # Data de referência do dia clínico
    day_label = Column(String, nullable=True)  # "D1", "D2", "D7", etc.
    type = Column(String, nullable=False, default="UTI")  # "UTI" ou "SALA_VERMELHA"
    
    # Texto original livre
    raw_text = Column(Text, nullable=True)
    
    # Dados estruturados do Dashboard 360º
    structured_data = Column(Text, nullable=True)  # Dados organizados por sistemas (JSON como texto)
    
    # Status visual
    critical_status = Column(String, default="stable", nullable=False)  # "critical", "alert", "stable"
    
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    admission = relationship("Admission", back_populates="dashboards")