#!/usr/bin/env python3
"""
Script para criar usuário admin inicial e testar o backend.
"""
import sys
import os
from datetime import datetime

# Add the app directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'app'))

from app.models import User
from app.db.session import SessionLocal
from app.core.security import get_password_hash
from app.models.user import UserRole
import hashlib

def create_admin_user():
    """Cria um usuário admin inicial."""
    db = SessionLocal()
    
    try:
        # Verificar se já existe um admin
        admin = db.query(User).filter(User.role == UserRole.ADMIN).first()
        if admin:
            print(f"Usuário admin já existe: {admin.email}")
            return admin
        
        # Criar usuário admin com senha simples para desenvolvimento
        admin_user = User(
            name="Administrador",
            email="admin@uti.com",
            password_hash=hashlib.sha256("admin123".encode()).hexdigest(),
            role=UserRole.ADMIN,
            active="true"
        )
        
        db.add(admin_user)
        db.commit()
        db.refresh(admin_user)
        
        print(f"Usuário admin criado com sucesso!")
        print(f"Email: {admin_user.email}")
        print(f"Senha: admin123")
        
        return admin_user
        
    except Exception as e:
        db.rollback()
        print(f"Erro ao criar usuário admin: {e}")
        return None
    finally:
        db.close()

if __name__ == "__main__":
    create_admin_user()