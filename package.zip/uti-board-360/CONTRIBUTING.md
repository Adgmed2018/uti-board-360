# 🤝 Contribuindo para o UTI Board 360

Obrigado pelo seu interesse em contribuir para o UTI Board 360! Este documento fornece diretrizes para contribuir com o projeto.

## 📋 Índice

- [Código de Conduta](#código-de-conduta)
- [Como Contribuir](#como-contribuir)
- [Estrutura do Projeto](#estrutura-do-projeto)
- [Setup de Desenvolvimento](#setup-de-desenvolvimento)
- [Padrões de Código](#padrões-de-código)
- [Testes](#testes)
- [Processo de Pull Request](#processo-de-pull-request)
- [Reportando Bugs](#reportando-bugs)
- [Solicitando Features](#solicitando-features)

## 🎯 Código de Conduta

Este projeto adere ao código de conduta descrito em [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md). Ao participar, espera-se que você mantenha este padrão.

## 🚀 Como Contribuir

Existem várias formas de contribuir com o projeto:

### 🐛 Reportando Bugs
- Use o template de issue para bugs
- Forneça passos detalhados para reproduzir
- Inclua informações do ambiente (OS, browser, versão)

### 💡 Sugerindo Features
- Use o template de issue para features
- Explique claramente o problema que a feature resolve
- Seja específico sobre a implementação desejada

### 🔧 Corrigindo Bugs
- Escolha issues com label `good first issue`
- Fork o repositório
- Crie uma branch para sua correção
- Implemente os testes
- Submeta um pull request

### 📝 Melhorando Documentação
- Corrija erros ortográficos
- Adicione exemplos de uso
- Melhore clareza e organização

### 🌐 Traduções
- Adicione suporte para outros idiomas
- Mantenha consistência terminológica médica

## 🏗️ Estrutura do Projeto

```
uti-board-360/
├── backend/                 # FastAPI Backend
│   ├── app/
│   │   ├── core/           # Configurações e segurança
│   │   ├── db/             # Configuração do banco
│   │   ├── models/         # Modelos SQLAlchemy
│   │   ├── routers/        # Rotas da API
│   │   ├── schemas/        # Schemas Pydantic
│   │   └── main.py         # Aplicação principal
│   ├── alembic/            # Migrações
│   └── tests/              # Testes do backend
├── frontend/               # React Frontend
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── hooks/          # Custom hooks
│   │   ├── lib/            # Utilitários
│   │   └── App.tsx         # Aplicação principal
│   └── tests/              # Testes do frontend
├── .github/workflows/      # GitHub Actions
├── docs/                   # Documentação
└── docker-compose.yml      # Orquestração Docker
```

## 🛠️ Setup de Desenvolvimento

### Pré-requisitos
- Node.js 18+
- Python 3.11+
- pnpm (recomendado) ou npm
- Docker (opcional)

### 1. Clone o Repositório
```bash
git clone https://github.com/seu-usuario/uti-board-360.git
cd uti-board-360
```

### 2. Setup do Backend
```bash
cd backend

# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows

# Instalar dependências
pip install -r requirements.txt

# Configurar banco de dados
python create_tables.py
python create_admin.py

# Executar servidor
python -m uvicorn app.main:app --reload
```

### 3. Setup do Frontend
```bash
# Instalar dependências
pnpm install

# Executar em desenvolvimento
pnpm dev
```

### 4. Setup com Docker
```bash
# Subir toda stack
docker-compose up -d

# Ver logs
docker-compose logs -f
```

## 📏 Padrões de Código

### Backend (Python/FastAPI)

#### Estilo de Código
- Siga [PEP 8](https://pep8.org/)
- Use `black` para formatação
- Use `isort` para importações
- Use `flake8` para linting

#### Nomenclatura
- **Funções e variáveis**: `snake_case`
- **Classes**: `PascalCase`
- **Constantes**: `UPPER_SNAKE_CASE`
- **Arquivos**: `snake_case.py`

#### Estrutura de Código
```python
# 1. Imports (standard library, third party, local)
import os
from fastapi import FastAPI
from app.models import User

# 2. Constants
DATABASE_URL = "sqlite:///./app.db"

# 3. Functions
def get_db():
    """Get database session."""
    pass

# 4. Classes
class UserService:
    """User service class."""
    pass

# 5. Main application
app = FastAPI()
```

### Frontend (React/TypeScript)

#### Estilo de Código
- Use [ESLint](https://eslint.org/) e [Prettier](https://prettier.io/)
- Siga [Airbnb JavaScript Style Guide](https://github.com/airbnb/javascript)

#### Nomenclatura
- **Componentes**: `PascalCase`
- **Hooks**: `camelCase` começando com 'use'
- **Utilitários**: `camelCase`
- **Constantes**: `UPPER_SNAKE_CASE`

#### Estrutura de Componente
```tsx
// 1. Imports
import { useState } from 'react';
import { User } from '../types';

// 2. Types
interface Props {
  user: User;
}

// 3. Component
const UserCard: React.FC<Props> = ({ user }) => {
  // 4. Hooks
  const [isLoading, setIsLoading] = useState(false);

  // 5. Event handlers
  const handleClick = () => {
    setIsLoading(true);
  };

  // 6. Render
  return (
    <div className="user-card">
      <h2>{user.name}</h2>
      <button onClick={handleClick} disabled={isLoading}>
        {isLoading ? 'Loading...' : 'Click me'}
      </button>
    </div>
  );
};

export default UserCard;
```

## 🧪 Testes

### Backend Tests
```bash
cd backend
python -m pytest tests/ -v --cov=app
```

### Frontend Tests
```bash
pnpm test
```

### Coverage Targets
- **Backend**: > 80%
- **Frontend**: > 80%

## 🔄 Processo de Pull Request

### 1. Preparação
1. Fork o repositório
2. Crie uma branch: `git checkout -b feature/nova-funcionalidade`
3. Implemente suas mudanças
4. Adicione testes
5. Execute todos os testes
6. Atualize a documentação

### 2. Commit
Use mensagens de commit claras e convencionais:

```
tipo(escopo): descrição breve

Descrição mais detalhada, se necessário.

- Lista de mudanças
- Bullet points são ok
- Issues fechadas: #123
```

Tipos:
- `feat`: Nova funcionalidade
- `fix`: Correção de bug
- `docs`: Mudanças na documentação
- `style`: Formatação, quebras de linha, etc.
- `refactor`: Refatoração de código
- `test`: Adição ou correção de testes
- `chore`: Mudanças no build process, dependências

### 3. Pull Request
1. Certifique-se de que todos os testes passam
2. Atualize o README.md se necessário
3. Descreva claramente o que foi implementado
4. Referencie issues relacionadas

#### Template de Pull Request
```markdown
## 📝 Descrição
Breve descrição das mudanças implementadas.

## 🔍 Tipo de Mudança
- [ ] Bug fix (mudança não disruptiva que corrige um issue)
- [ ] Nova feature (mudança não disruptiva que adiciona funcionalidade)
- [ ] Breaking change (correção ou feature que causaria funcionalidade existente não funcionar como esperado)
- [ ] Documentação

## ✅ Checklist
- [ ] Meus commits seguem o padrão de commit do projeto
- [ ] Meus testes adicionam cobertura adequada
- [ ] Testes locais passam
- [ ] Documentação foi atualizada (se aplicável)

## 🧪 Testes
- [ ] Testes de unidade
- [ ] Testes de integração
- [ ] Testes manuais

## 📋 Notas Adicionais
Qualquer informação adicional ou screenshots sobre as mudanças.
```

## 🐛 Reportando Bugs

### Antes de Reportar
- Verifique se já existe uma issue similar
- Certifique-se de que está usando a versão mais recente
- Reproduza o bug consistentemente

### Template de Bug Report
```markdown
## 🐛 Bug Description
Descrição clara e concisa do bug.

## 🔄 Steps to Reproduce
1. Vá para '...'
2. Clique em '....'
3. Veja erro

## ✅ Expected Behavior
Descrição do que deveria acontecer.

## 📸 Screenshots
Se aplicável, adicione screenshots.

## 🔧 Environment
- OS: [e.g. Windows 10]
- Browser: [e.g. Chrome 92]
- Version: [e.g. 1.0.0]
- Backend Version: [e.g. API v1.0.0]

## 📝 Additional Context
Qualquer contexto adicional sobre o problema.
```

## 💡 Solicitando Features

### Template de Feature Request
```markdown
## 💡 Feature Description
Descrição clara da feature desejada.

## 🎯 Problem/Need
Qual problema esta feature resolve? Qual é seu caso de uso?

## 💭 Proposed Solution
Descrição de como você gostaria que a feature funcionasse.

## 🔄 Alternative Solutions
Descrição de soluções ou features alternativas que você considerou.

## 📋 Additional Context
Screenshots, mockups ou contexto adicional.
```

## 📚 Recursos Úteis

### Documentação
- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [React Docs](https://reactjs.org/docs)
- [TypeScript Docs](https://www.typescriptlang.org/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)

### Ferramentas
- [VS Code](https://code.visualstudio.com/)
- [Docker](https://docs.docker.com/)
- [Postman](https://www.postman.com/) (para testar APIs)

## ⚠️ Considerações Médicas

### Limitações Éticas
Lembre-se sempre que este sistema:
- ❌ **NÃO** sugere diagnósticos
- ❌ **NÃO** recomenda tratamentos
- ❌ **NÃO** interpreta exames
- ❌ **NÃO** faz prescrições
- ✅ **APENAS** organiza informações existentes

### Padrões Médicos
- Use terminologia médica apropriada
- Mantenha conformidade com padrões internacionais
- Considere aspectos de privacidade e LGPD

## 📞 Suporte

Se tiver dúvidas sobre contribuições:
- Abra uma issue com label `question`
- Consulte a [documentação](../README.md)
- Entre em contato com os mantenedores

---

**🙏 Obrigado por contribuir para o UTI Board 360!** 

Cada contribuição ajuda a tornar o sistema melhor para profissionais de saúde em todo o mundo.