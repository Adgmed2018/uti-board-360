import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import LoginPage from './components/LoginPage';
import Layout from './components/Layout';
import DashboardPage from './components/DashboardPage';
import './App.css';

function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route
            path="/login"
            element={
              user ? <Navigate to="/dashboard" replace /> : <LoginPage />
            }
          />
          <Route
            path="/*"
            element={
              user ? (
                <Layout />
              ) : (
                <Navigate to="/login" replace />
              )
            }
          >
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="patients" element={<PatientsPage />} />
            <Route path="admissions" element={<AdmissionsPage />} />
            <Route path="dashboards" element={<DashboardsPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route index element={<Navigate to="/dashboard" replace />} />
          </Route>
        </Routes>
      </div>
    </Router>
  );
}

// Placeholder components for routes
const PatientsPage = () => (
  <div className="space-y-6">
    <h1 className="text-2xl font-bold text-white">Pacientes</h1>
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <p className="text-slate-400">Página de pacientes em desenvolvimento...</p>
    </div>
  </div>
);

const AdmissionsPage = () => (
  <div className="space-y-6">
    <h1 className="text-2xl font-bold text-white">Internações</h1>
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <p className="text-slate-400">Página de internações em desenvolvimento...</p>
    </div>
  </div>
);

const DashboardsPage = () => (
  <div className="space-y-6">
    <h1 className="text-2xl font-bold text-white">Dashboards</h1>
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <p className="text-slate-400">Página de dashboards em desenvolvimento...</p>
    </div>
  </div>
);

const SettingsPage = () => (
  <div className="space-y-6">
    <h1 className="text-2xl font-bold text-white">Configurações</h1>
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <p className="text-slate-400">Página de configurações em desenvolvimento...</p>
    </div>
  </div>
);

export default App;