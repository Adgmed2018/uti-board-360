import { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import api from '../lib/api';
import {
  UserGroupIcon,
  ClipboardDocumentListIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';

interface DashboardStats {
  totalPatients: number;
  activeAdmissions: number;
  criticalPatients: number;
  recentDashboards: number;
}

const DashboardPage = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    totalPatients: 0,
    activeAdmissions: 0,
    criticalPatients: 0,
    recentDashboards: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch patients count
      const patientsResponse = await api.get('/patients');
      const patients = patientsResponse.data;
      
      // Fetch active admissions
      const admissionsResponse = await api.get('/admissions/active/unit/UTI');
      const admissions = admissionsResponse.data;
      
      // For now, we'll simulate critical patients (in real app, this would come from dashboard data)
      const criticalPatients = Math.floor(admissions.length * 0.2); // Simulate 20% critical
      
      // Fetch recent dashboards
      const dashboardsResponse = await api.get('/dashboards/unit/UTI/active');
      const dashboards = dashboardsResponse.data;
      
      setStats({
        totalPatients: patients.length,
        activeAdmissions: admissions.length,
        criticalPatients,
        recentDashboards: dashboards.length,
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      name: 'Total de Pacientes',
      value: stats.totalPatients,
      icon: UserGroupIcon,
      color: 'bg-blue-500',
      textColor: 'text-blue-600',
    },
    {
      name: 'Internações Ativas',
      value: stats.activeAdmissions,
      icon: ClipboardDocumentListIcon,
      color: 'bg-green-500',
      textColor: 'text-green-600',
    },
    {
      name: 'Pacientes Críticos',
      value: stats.criticalPatients,
      icon: ExclamationTriangleIcon,
      color: 'bg-red-500',
      textColor: 'text-red-600',
    },
    {
      name: 'Dashboards Recentes',
      value: stats.recentDashboards,
      icon: CheckCircleIcon,
      color: 'bg-purple-500',
      textColor: 'text-purple-600',
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome header */}
      <div>
        <h1 className="text-2xl font-bold text-white">
          Bem-vindo, {user?.name}
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          Visão geral da Unidade de Terapia Intensiva
        </p>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => (
          <div
            key={stat.name}
            className="bg-slate-800 overflow-hidden shadow rounded-lg border border-slate-700"
          >
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className={`${stat.color} rounded-md p-3`}>
                    <stat.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-slate-400 truncate">
                      {stat.name}
                    </dt>
                    <dd className="text-lg font-medium text-white">
                      {stat.value}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="bg-slate-800 shadow rounded-lg border border-slate-700">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-white mb-4">
            Ações Rápidas
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <button className="relative group bg-slate-700 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500 rounded-lg hover:bg-slate-600 transition-colors">
              <div>
                <span className="rounded-lg inline-flex p-3 bg-blue-600 text-white">
                  <UserGroupIcon className="h-6 w-6" />
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-medium text-white">
                  <span className="absolute inset-0" />
                  Novo Paciente
                </h3>
                <p className="mt-2 text-sm text-slate-400">
                  Cadastrar novo paciente no sistema
                </p>
              </div>
            </button>

            <button className="relative group bg-slate-700 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500 rounded-lg hover:bg-slate-600 transition-colors">
              <div>
                <span className="rounded-lg inline-flex p-3 bg-green-600 text-white">
                  <ClipboardDocumentListIcon className="h-6 w-6" />
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-medium text-white">
                  <span className="absolute inset-0" />
                  Nova Internação
                </h3>
                <p className="mt-2 text-sm text-slate-400">
                  Iniciar nova internação
                </p>
              </div>
            </button>

            <button className="relative group bg-slate-700 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500 rounded-lg hover:bg-slate-600 transition-colors">
              <div>
                <span className="rounded-lg inline-flex p-3 bg-purple-600 text-white">
                  <CheckCircleIcon className="h-6 w-6" />
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-medium text-white">
                  <span className="absolute inset-0" />
                  Novo Dashboard
                </h3>
                <p className="mt-2 text-sm text-slate-400">
                  Criar Dashboard 360º do dia
                </p>
              </div>
            </button>

            <button className="relative group bg-slate-700 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500 rounded-lg hover:bg-slate-600 transition-colors">
              <div>
                <span className="rounded-lg inline-flex p-3 bg-yellow-600 text-white">
                  <ClockIcon className="h-6 w-6" />
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-medium text-white">
                  <span className="absolute inset-0" />
                  Timeline
                </h3>
                <p className="mt-2 text-sm text-slate-400">
                  Visualizar evolução temporal
                </p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Recent activity placeholder */}
      <div className="bg-slate-800 shadow rounded-lg border border-slate-700">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-white mb-4">
            Atividade Recente
          </h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span className="text-slate-400">Dashboard atualizado para Paciente João Silva</span>
              <span className="text-slate-500">há 5 minutos</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span className="text-slate-400">Nova internação criada - Leito 12A</span>
              <span className="text-slate-500">há 15 minutos</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span className="text-slate-400">Paciente crítico identificado - Leito 8B</span>
              <span className="text-slate-500">há 1 hora</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;